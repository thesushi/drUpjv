<?php
/**
 * @file
 * Contains \Drupal\ctools\ContextNotFoundException.
 */

namespace Drupal\ctools;


class ContextNotFoundException extends \Exception {}
