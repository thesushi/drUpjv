<?php

/**
 * @file
 * Contains \Drupal\xmlsitemap\XmlSitemapException.
 */

namespace Drupal\xmlsitemap;

/**
 * Basic XmlSitemapException class.
 */
class XmlSitemapException extends \Exception {

}
