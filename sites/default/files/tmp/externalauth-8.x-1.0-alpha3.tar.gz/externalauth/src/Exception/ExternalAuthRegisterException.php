<?php

/**
 * @file
 * Contains \Drupal\externalauth\Exception\ExternalAuthRegisterException.
 */

namespace Drupal\externalauth\Exception;

/**
 * Class ExternalAuthRegisterException.
 */
class ExternalAuthRegisterException extends \Exception {}
